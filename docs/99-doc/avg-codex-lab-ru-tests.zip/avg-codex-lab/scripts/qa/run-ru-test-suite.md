# Как запускать русскоязычный комплект тестов

## 1. Ручная проверка

Открыть:

```text
tests/ru/manual/smoke-checklist.md
tests/ru/manual/basic-functional-cases.md
```

Пройти чек-лист и сохранить отчёт в:

```text
artifacts/qa/ru-smoke-report-YYYY-MM-DD.md
```

## 2. E2E

После реализации UI снять `test.skip` в:

```text
tests/e2e/ru-basic.spec.ts
tests/e2e/ru-dialogue-modes.spec.ts
tests/e2e/ru-security.spec.ts
```

Запустить:

```bash
pnpm test:e2e
```

## 3. AI-evals

Подключить eval runner к YAML из:

```text
tests/ru/ai-evals/
```

Запустить:

```bash
pnpm test:ai
```

## 4. Security

Пройти:

```text
tests/ru/security/prompt-injection-cases.md
```

И проверить, что все P0 cases проходят.
