import { describe, it, expect } from 'vitest';

describe.skip('RU AVG: валидатор утверждений', () => {
  it('помечает сильные слова как риск', async () => {
    // TODO: импортировать validateClaim из packages/avg-validation после реализации.
    const statement = 'AVG раскрывает истинную сущность человека';
    expect(statement).toContain('истинную сущность');
  });

  it('различает метафору и факт', async () => {
    const statement = 'Психика — это замок с тайными комнатами';
    expect(statement).toContain('замок');
  });
});
