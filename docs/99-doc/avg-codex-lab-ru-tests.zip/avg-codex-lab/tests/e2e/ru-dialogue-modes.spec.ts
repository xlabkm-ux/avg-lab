import { test, expect } from '@playwright/test';

test.describe.skip('RU AVG: режимы диалога', () => {
  test('режим Валидатор ловит сильные слова', async ({ page }) => {
    await page.goto('/projects/test');
    await page.getByRole('textbox', { name: /сообщение/i }).fill('Проверь: система раскрывает истинную сущность человека');
    await page.getByRole('button', { name: /отправить/i }).click();

    await expect(page.getByText(/сильн/i)).toBeVisible();
    await expect(page.getByText(/истинная сущность/i)).toBeVisible();
    await expect(page.getByText(/гипотеза|метафора|риск/i)).toBeVisible();
  });

  test('режим Разгон создаёт несколько разных идей', async ({ page }) => {
    await page.goto('/projects/test');
    await page.getByRole('textbox', { name: /сообщение/i }).fill('Режим Разгон: дай 15 идей для образовательной платформы');
    await page.getByRole('button', { name: /отправить/i }).click();

    await expect(page.getByText(/1\.|вариант 1/i)).toBeVisible();
    await expect(page.getByText(/10\.|вариант 10/i)).toBeVisible();
  });
});
