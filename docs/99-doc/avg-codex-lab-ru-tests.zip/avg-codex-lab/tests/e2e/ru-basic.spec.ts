import { test, expect } from '@playwright/test';

test.describe.skip('RU AVG: базовый пользовательский путь', () => {
  test('пользователь создаёт проект, получает концепт и сохраняет артефакт', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('button', { name: /создать проект/i }).click();
    await page.getByLabel(/название проекта/i).fill('Тест AVG: школа нового типа');
    await page.getByRole('button', { name: /создать/i }).click();

    await expect(page.getByText(/Тест AVG: школа нового типа/i)).toBeVisible();

    await page.getByRole('textbox', { name: /сообщение/i }).fill('Создай концепт школы нового типа');
    await page.getByRole('button', { name: /отправить/i }).click();

    await expect(page.getByText(/концепт/i)).toBeVisible();
    await expect(page.getByText(/риски|ограничения/i)).toBeVisible();
    await expect(page.getByText(/следующий шаг/i)).toBeVisible();

    await page.getByRole('button', { name: /сохранить как артефакт/i }).click();
    await expect(page.getByText(/артефакт сохранён/i)).toBeVisible();
  });
});
