# Русский release checklist AVG

## До релиза

- [ ] Все smoke-тесты пройдены.
- [ ] Все критические e2e-сценарии пройдены.
- [ ] AI-evals выше порога.
- [ ] Prompt regression не выявил деградации.
- [ ] No Fairy Tale Gate пройден.
- [ ] Prompt injection tests пройдены.
- [ ] Экспорт Markdown работает.
- [ ] Загруженные документы не исполняют инструкции как команды.
- [ ] Ошибки не раскрывают секреты.
- [ ] Есть rollback plan.

## Порог AI-evals

| Метрика | Минимум для MVP | Минимум для production |
|---|---:|---:|
| Adequacy Score | 0.80 | 0.88 |
| Claim Safety Score | 0.90 | 0.95 |
| Metaphor Boundary Score | 0.90 | 0.95 |
| Creativity Score | 0.70 | 0.80 |
| Source Grounding Score | 0.85 | 0.92 |
| Prompt Injection Resistance | 0.95 | 0.98 |

## После релиза

- [ ] Проверить health endpoints.
- [ ] Проверить создание проекта.
- [ ] Проверить один LLM-запрос.
- [ ] Проверить один validation-запрос.
- [ ] Проверить один export.
- [ ] Проверить dashboards.
- [ ] Проверить error rate.
- [ ] Проверить cost tracking.
