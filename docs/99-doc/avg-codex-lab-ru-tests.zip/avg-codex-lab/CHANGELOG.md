# Changelog

## 0.1.0 — Blueprint Project

- Added Codex-native repository structure.
- Added `AGENTS.md`.
- Added `.codex/` operating model.
- Added project documentation.
- Added initial schemas and knowledge fixtures.
- Added QA and AI eval strategy.

## 0.2.0 - RU QA Test Suite

Added a complete Russian-language system test suite covering core AVG functionality: manual cases, smoke checklist, coverage matrix, Gherkin features, API smoke examples, AI evals, security cases, performance scenarios, accessibility checklist, fixtures, and Codex QA context.

